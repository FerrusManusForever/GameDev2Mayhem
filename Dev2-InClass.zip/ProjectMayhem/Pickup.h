#pragma once
class Pickup
{
};

