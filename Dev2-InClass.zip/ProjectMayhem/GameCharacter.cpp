#include "GameCharacter.h"

GameCharacter::GameCharacter()
{
	
}
GameCharacter::~GameCharacter()
{

}

void GameCharacter::CollectPickup(Pickup& pickup)
{
}

void GameCharacter::Attack(GameCharacter& target)
{
}
