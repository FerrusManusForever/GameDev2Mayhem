#pragma once
#include "GameCharacter.h"
class Goblin : public GameCharacter
{
};

