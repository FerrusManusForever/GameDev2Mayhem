#include "PointerDemo.h"

void PointerDemo::DoDemo()
{
	

}

void PointerDemo::PassByValueDemo()
{
}

void PointerDemo::PassByReferenceDemo()
{
}
