#pragma once
#include "GameCharacter.h"
class Player :public GameCharacter
{
};

