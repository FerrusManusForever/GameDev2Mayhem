#pragma once
enum Direction
{
	North,
	East,
	South,
	West
};

