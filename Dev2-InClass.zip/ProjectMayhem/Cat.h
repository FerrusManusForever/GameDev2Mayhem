#pragma once
class Cat
{
public:

private:

};

